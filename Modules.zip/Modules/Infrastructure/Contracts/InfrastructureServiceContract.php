<?php

namespace Modules\Infrastructure\Contracts;

interface InfrastructureServiceContract
{
}
