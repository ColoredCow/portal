@extends('invoice::layouts.master')
@section('content')

<div class="container">
    <br>
    
    <div class="d-flex justify-content-between mb-2"> 
        <h4>Invoice Information</h4>
        <span>
            <a class="btn btn-sm btn-info text-white mr-4 font-weight-bold" onclick="alert('Will add this soon')" href="#">Duplicate this invoice</a>
            <a class="btn btn-sm btn-info text-white font-weight-bold" target="_blank" href="{{ route('invoice.get-file', $invoice->id) }}">View invoice PDF</a>
        </span>
    </div>
    <form method="POST" action="{{ route('invoice.update', $invoice) }}" enctype="multipart/form-data">
        @csrf
        <div class="card">
            @include('status', ['errors' => $errors->all()])
            @include('invoice::subviews.edit.invoice-details')
        </div>
    </form>
</div>

@endsection