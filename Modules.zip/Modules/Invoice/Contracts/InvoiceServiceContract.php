<?php

namespace Modules\Invoice\Contracts;

interface InvoiceServiceContract
{
}
