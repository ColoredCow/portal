<?php

namespace Modules\Invoice\Contracts;

interface CurrencyServiceContract
{
}
