<?php

namespace Modules\User\Contracts;

interface UserServiceContract
{
}
