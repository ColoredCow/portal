<?php

namespace Modules\User\Contracts;

interface ProfileServiceContract
{
}
