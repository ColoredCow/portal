@extends('layouts.app')
@section('js_scripts')
<script src="{{ mix('/js/user.js') }}" defer></script>
@endsection

@section('css_scripts')
<link href="{{ mix('/css/user.css') }}" rel="stylesheet">
@endsection