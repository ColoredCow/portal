<div>
        <div class="row">
                <div class="col-4">Name</div>
                <div class="col-4">ID</div>
                <div class="col-4">File</div>
        </div>
        <br>

        <div class="row">
                <div class="col-4">Pan Card</div>
                <div class="col-4"><a href="#"> View </a></div>
                <div class="col-4"><a href="#"> Upload New </a></div>
        </div>

        <br>
        <div class="row">
                <div class="col-4">Adhar Card</div>
                <div class="col-4"><a href="#"> View </a></div>
                <div class="col-4"><a href="#"> Upload New </a></div>
        </div>

        <br>

        <div class="row">
                <div class="col-4">Signature</div>
                <div class="col-4"><a href="#"> View </a></div>
                <div class="col-4"><a href="#"> Upload New </a></div>
        </div>

</div>