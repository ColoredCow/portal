<div>
    <h3 class="text-underline">Bank Info</h3>
    <br>

    <div>
        <div class="form-group">
            <label class="font-weight-bold" for="">Bank Name:</label>
            <span>State bank of india</span>
        </div>
        <div class="form-group">
            <label class="font-weight-bold" for="">IFCS Code</label>
            <span>123123312</span>
        </div>

    </div>

</div>

<br>

<div>
    <h3 class="text-underline">Salery</h3>
    <br>

    <div>
        <div class="form-group">
            <label class="font-weight-bold" for="">Basic Salery:</label>
            <span>10000</span>
        </div>
        <div class="form-group">
            <label class="font-weight-bold" for="">HRA:</label>
            <span>120</span>
        </div>

    </div>

</div>