<?php

return [
    'name' => 'User',
    //'extended_class' => 'App\Services\ExtendedUserService'
];
