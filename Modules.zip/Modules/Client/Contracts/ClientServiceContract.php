<?php

namespace Modules\Client\Contracts;

interface ClientServiceContract
{
}
