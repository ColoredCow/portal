<?php

namespace Modules\ModuleChecklist\Entities;

use Illuminate\Database\Eloquent\Model;

class NDAMeta extends Model
{
    protected $fillable = [];
    protected $table = 'nda_meta';
}
