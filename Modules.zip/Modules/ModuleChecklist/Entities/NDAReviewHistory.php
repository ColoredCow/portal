<?php

namespace Modules\ModuleChecklist\Entities;

use Illuminate\Database\Eloquent\Model;

class NDAReviewHistory extends Model
{
    protected $fillable = [];
}
