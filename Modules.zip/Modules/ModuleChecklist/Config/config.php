<?php

return [
    'name' => 'ModuleChecklist'
];
