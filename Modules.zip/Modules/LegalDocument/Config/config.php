<?php

return [
    'name' => 'LegalDocument'
];
