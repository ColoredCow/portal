@extends('layouts.app')
@section('js_scripts')
@endsection

@section('css_scripts')
@endsection
