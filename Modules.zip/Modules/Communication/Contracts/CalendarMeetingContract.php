<?php

namespace Modules\Communication\Contracts;

interface CalendarMeetingContract
{
    /**
     * Can not set the name as CalendarMeetingServiceContract, looks like it's too long for composer
     */
}
