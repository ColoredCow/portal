<?php

namespace Modules\SalesAutomation\Entities;

use Illuminate\Database\Eloquent\Model;

class SalesCharacteristic extends Model
{
    protected $guarded = [];
}
