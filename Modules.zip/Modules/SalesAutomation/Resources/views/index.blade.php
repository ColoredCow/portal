@extends('salesautomation::layouts.master')

@section('salesautomation.content')
    <h1>Sales Automation</h1>
@endsection
