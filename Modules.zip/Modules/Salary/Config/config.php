<?php

return [
    'name' => 'Salary'
];
