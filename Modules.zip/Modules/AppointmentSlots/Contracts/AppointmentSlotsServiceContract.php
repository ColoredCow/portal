<?php

namespace Modules\AppointmentSlots\Contracts;

interface AppointmentSlotsServiceContract
{
}
