<?php

return [
    'name' => 'AppointmentSlots',
    'google_calendar' => [
        'url' => 'https://calendar.google.com/calendar/u/0/r/day/',
    ],
];
