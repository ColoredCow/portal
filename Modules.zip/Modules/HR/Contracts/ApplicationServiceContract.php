<?php

namespace Modules\HR\Contracts;

interface ApplicationServiceContract
{
}
