<?php

namespace Modules\EffortTracking\Contracts;

interface TaskServiceContract
{
}
