@extends('layouts.app')

@section('css_scripts')
	<link href="{{ mix('/css/efforttracking.css') }}" rel="stylesheet">
@endsection

@section('js_scripts')
	<script src="{{ mix('/js/efforttracking.js') }}"></script>
@endsection
