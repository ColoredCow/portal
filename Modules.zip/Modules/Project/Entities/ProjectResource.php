<?php

namespace Modules\Project\Entities;

use Illuminate\Database\Eloquent\Model;

class ProjectResource extends Model
{
    protected $guarded = [];
    protected $table = 'project_resource';
}
