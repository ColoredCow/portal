<?php

namespace Modules\Project\Contracts;

interface ProjectServiceContract
{
}
