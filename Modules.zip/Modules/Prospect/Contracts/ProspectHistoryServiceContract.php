<?php

namespace Modules\Prospect\Contracts;

interface ProspectHistoryServiceContract
{
}
