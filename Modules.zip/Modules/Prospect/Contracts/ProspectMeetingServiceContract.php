<?php

namespace Modules\Prospect\Contracts;

interface ProspectMeetingServiceContract
{
}
