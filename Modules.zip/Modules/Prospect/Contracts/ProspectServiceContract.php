<?php

namespace Modules\Prospect\Contracts;

interface ProspectServiceContract
{
}
