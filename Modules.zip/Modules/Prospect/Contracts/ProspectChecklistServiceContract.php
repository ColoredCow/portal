<?php

namespace Modules\Prospect\Contracts;

interface ProspectChecklistServiceContract
{
}
