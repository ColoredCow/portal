Vue.component('prospect-history', require('./components/ProspectHistory.vue').default);
Vue.component('prospect-history-item', require('./components/ProspectProgressItem.vue').default);