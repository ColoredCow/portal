<?php

namespace Modules\Prospect\Entities;

use Illuminate\Database\Eloquent\Model;

class ProspectDocument extends Model
{
    // protected $fillable = ['created_by', 'prospect_stage_id', 'prospect_id', 'description'];

    // protected $appends = ['performed_on', 'performed_by', 'performed_as'];
}
