<?php

namespace Modules\Prospect\Entities;

use Illuminate\Database\Eloquent\Model;

class ProspectAgreement extends Model
{
    protected $fillable = [];
}
